# UBER-data-analysis :cherry_blossom:
> **Data analysis on UBER's data of ride calls from travellers** 

***I used simple python functions to get really facinating results from the data. After analysing the data we got the following output results.***
- Generated the map of the place where data belongs to.
- Generated heatmap of the user requesting for rides over the week.
- Generated the hourly, day wise, weekly and monthly plots of user requests.
- Although it was not told in the data that to what place the data belongs to, but still I was able to get the location of the place where data belongs, *it was **Manhattan*** :trollface:.
